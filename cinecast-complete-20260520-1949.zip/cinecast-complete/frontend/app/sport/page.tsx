"use client";

import VideoPlayer from "@/components/VideoPlayer";

const SPORT_STREAM = "https://lb10.strmd.top/secure/.../stream/.../mono.m3u8";

export default function SportPage() {
  return (
    <div className="browse-page">
      <header className="browse-header">
        <h1>Sport</h1>
        <p>Live sport stream.</p>
      </header>
      <div style={{ maxWidth: 1100, margin: "0 auto" }}>
        <VideoPlayer src={SPORT_STREAM} title="Sport" />
      </div>
    </div>
  );
}
