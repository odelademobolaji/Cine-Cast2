"use client";

import { useEffect, useMemo, useState } from "react";

export interface EmbedSource {
  name: string;
  url: string;
  unavailableReason?: string;
}

interface EmbedPlayerProps {
  title: string;
  sources: EmbedSource[];
}

export default function EmbedPlayer({ title, sources }: EmbedPlayerProps) {
  const playableSources = useMemo(
    () => sources.filter((source) => source.url.trim().length > 0),
    [sources]
  );
  const [activeIndex, setActiveIndex] = useState(0);
  const activeSource = playableSources[activeIndex] || playableSources[0];

  // Block ad popups spawned by embed providers.
  // Three layers:
  //   1. iframe sandbox (no allow-popups) — kills window.open() inside the iframe at browser level
  //   2. window.open override — catches anything that escapes to the parent context
  //   3. blur re-focus — if a popup still manages to open, immediately steal focus back
  useEffect(() => {
    const originalOpen = window.open.bind(window);
    window.open = () => null;

    const handleBlur = () => {
      // Re-focus this window a tick later so any opened popup loses focus immediately
      window.setTimeout(() => window.focus(), 50);
    };
    window.addEventListener("blur", handleBlur);

    return () => {
      window.open = originalOpen;
      window.removeEventListener("blur", handleBlur);
    };
  }, []);

  if (!activeSource) {
    return <div className="embed-empty">No embed source is configured for this title.</div>;
  }

  return (
    <div className="embed-shell">
      <div className="embed-controls" aria-label="Embed source controls">
        <div className="embed-source-tabs" role="tablist" aria-label="Video sources">
          {sources.map((source) => {
            const playableIndex = playableSources.findIndex((playableSource) => playableSource.name === source.name);
            const isPlayable = playableIndex >= 0;
            return (
              <button
                key={source.name}
                type="button"
                className={`embed-source-tab${playableIndex === activeIndex ? " is-active" : ""}${isPlayable ? "" : " is-disabled"}`}
                onClick={() => {
                  if (isPlayable) setActiveIndex(playableIndex);
                }}
                role="tab"
                aria-selected={playableIndex === activeIndex}
                aria-disabled={!isPlayable}
                disabled={!isPlayable}
                title={source.unavailableReason}
              >
                {source.name}
              </button>
            );
          })}
        </div>
        <button
          type="button"
          className="embed-next"
          onClick={() => setActiveIndex((activeIndex + 1) % playableSources.length)}
        >
          Try next source
        </button>
      </div>

      {/*
        sandbox without allow-popups  → blocks window.open() inside the iframe
        sandbox without allow-top-navigation → blocks the iframe redirecting the parent page
        allow-same-origin is kept so video players can access localStorage/cookies they need
      */}
      <iframe
        key={activeSource.url}
        className="embed-player"
        src={activeSource.url}
        title={`${title} - ${activeSource.name}`}
        allow="autoplay; encrypted-media; fullscreen; picture-in-picture"
        referrerPolicy="origin"
        allowFullScreen
        sandbox="allow-scripts allow-same-origin allow-forms allow-presentation allow-pointer-lock"
      />
    </div>
  );
}
