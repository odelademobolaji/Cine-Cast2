"use client";

import { useMemo, useState } from "react";

export interface EmbedSource {
  name: string;
  url: string;
  unavailableReason?: string;
}

interface EmbedPlayerProps {
  title: string;
  sources: EmbedSource[];
}

export default function EmbedPlayer({ title, sources }: EmbedPlayerProps) {
  const playableSources = useMemo(
    () => sources.filter((source) => source.url.trim().length > 0),
    [sources]
  );
  const [activeIndex, setActiveIndex] = useState(0);
  const activeSource = playableSources[activeIndex] || playableSources[0];

  if (!activeSource) {
    return <div className="embed-empty">No embed source is configured for this title.</div>;
  }

  return (
    <div className="embed-shell">
      <div className="embed-controls" aria-label="Embed source controls">
        <div className="embed-source-tabs" role="tablist" aria-label="Video sources">
          {sources.map((source) => {
            const playableIndex = playableSources.findIndex((playableSource) => playableSource.name === source.name);
            const isPlayable = playableIndex >= 0;
            return (
              <button
                key={source.name}
                type="button"
                className={`embed-source-tab${playableIndex === activeIndex ? " is-active" : ""}${isPlayable ? "" : " is-disabled"}`}
                onClick={() => {
                  if (isPlayable) setActiveIndex(playableIndex);
                }}
                role="tab"
                aria-selected={playableIndex === activeIndex}
                aria-disabled={!isPlayable}
                disabled={!isPlayable}
                title={source.unavailableReason}
              >
                {source.name}
              </button>
            );
          })}
        </div>
        <button
          type="button"
          className="embed-next"
          onClick={() => setActiveIndex((activeIndex + 1) % playableSources.length)}
        >
          Try next source
        </button>
      </div>

      <iframe
        key={activeSource.url}
        className="embed-player"
        src={activeSource.url}
        title={`${title} - ${activeSource.name}`}
        allow="autoplay; encrypted-media; fullscreen; picture-in-picture"
        referrerPolicy="origin"
        allowFullScreen
      />
    </div>
  );
}
